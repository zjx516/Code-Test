import React from 'react';

import { BrowserRouter as Router, Route } from 'react-router-dom';

import Register from './module/Register';
import ListItem from './module/ListItem';
import EditItem from './module/EditItem';
import CreateItem from './module/CreateItem';
import Login from './module/Login';
import Message from './module/Message/LiuApp';
import Logout from './module/Logout';

function App() {

  return (
    <Router>
      <div className="App">
        
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <a className="navbar-brand" href="https://orbica.world" style={{color:'orange',fontWeight:'bold'}}>Orbica Test</a>
          <Logout/>
        </nav>

        <div className="container py-4">
          <div className="row">
            <Route path="/" exact component={Login} />
            <Route path="/listItem" exact component={ListItem} onEnter={Login.onEnter}/>
            <Route path="/edit" exact component={EditItem} onEnter={Login.onEnter}/>
            <Route path="/create" exact component={CreateItem} onEnter={Login.onEnter}/>
            <Route path="/register" exact component={Register} onEnter={Login.onEnter}/>
            <Route path="/message" exact component={Message} onEnter={Login.onEnter}/>
          </div>
        </div>

      </div>
    </Router>
  );

}

export default App;