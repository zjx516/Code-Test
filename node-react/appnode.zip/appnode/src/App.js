import React from 'react';

import { BrowserRouter as Router, Route } from 'react-router-dom';

import Register from './module/Page/RegisterPage';
import ListItem from './module/ListItem';
import EditItem from './module/EditItem';
import CreateItem from './module/CreateItem';
import LoginPage from './module/Page/LoginPage';
import Message from './module/Message/MessageApp';
import Logout from './module/Logout';
import Login from './module/Login';
import AuthRouter from './AuthRouter';

function App() {

  return (
    <Router>
      <div className="App">
        <nav className="navbar navbar-light bg-light">
          <a className="navbar-brand" href="https://orbica.world" style={{color:'orange',fontWeight:'bold'}}>Orbica Test</a>
          <span style={{float: "right"}}>
            {window.sessionStorage.getItem("username") === null?
              <Login/>:
              <Logout/>
            }
          </span>
        </nav>

        <div className="container py-4">
          <div className="row">
            <Route path="/login" exact component={LoginPage}/>
            <Route path="/register" exact component={Register}/>
            <Route path="/" exact component={ListItem}/>
            <AuthRouter path="/edit" exact component={EditItem}/>
            <AuthRouter path="/create" exact component={CreateItem}/>
            <AuthRouter path="/message" exact component={Message}/>
          </div>
        </div>

      </div>
    </Router>
  );

}

export default App;