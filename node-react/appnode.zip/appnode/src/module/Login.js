import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';


class Login extends React.Component{

      render(){
        return (
          <button className="btn btn-primary" style={{margin:"0 10px"}} onClick={()=>this.login()}>Login</button>
        )
      }

      login() {
        window.location.href="/login";
     }

}


export default Login;