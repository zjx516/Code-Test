import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';

class CreateItem extends React.Component{
    constructor(props){
        super(props);
        this.state = {
          campName: "",
          campPrice: "",
          campDescription: "",
          campExpiryDate: "",
          selectStatus: ""
        }
    }

  render(){
    return (
    <div>
    <div className="form-row justify-content-center">
      <div className="form-group col-12">
        <label>name</label>
        <input type="text" className="form-control" value={this.state.campName} onChange={(event)=> this.setState({campName:event.target.value})}/>
      </div>
      <div className="form-group col-12">
        <label>price</label>
        <input type="price" className="form-control" value={this.state.campPrice} onChange={(value)=> this.setState({campPrice:value.target.value})}/>
      </div>
    </div>
    <div className="form-row">
      <div className="form-group col-12">
        <label>description</label>
        <input type="text" className="form-control" value={this.state.campDescription} onChange={(value)=> this.setState({campDescription:value.target.value})}/>
      </div>
      <div className="form-group col-12">
        <label>expiry date</label>
        <input type="date" className="form-control" id="inputEmailAgain" value={this.state.campExpiryDate} onChange={(value)=> this.setState({campExpiryDate:value.target.value})}/>
      </div>
      <div className="form-group col-12">
        <label>status</label>
        <select id="inputStatus" className="form-control" value={this.state.selectStatus} onChange={(value)=> this.setState({selectStatus:value.target.value})}>
          <option selected>Choose...</option>
          <option value="Y">Y</option>
          <option value="N">N</option>
        </select>
      </div>
    </div>
    <button type="submit" className="btn btn-primary" onClick={()=>this.sendUpdate()}>Submit</button>
  </div>
   );
 }

 sendUpdate() {
    const baseUrl = "http://localhost:3001/item/create"
          const datapost = {
            name : this.state.campName,
            price : this.state.campPrice,
            description : this.state.campDescription,
            expiryDate : this.state.campExpiryDate,
            status : this.state.selectStatus
          }
     
          axios.post(baseUrl,datapost)
          .then(response=>{
            if (response.data.success===true) {
              alert(response.data.message);
              this.props.history.push("/listItem");
            }
            else {
              alert(response.data.message)
            }
          }).catch(error=>{
            alert("Error 34 "+error)
          })
  }

  picture(e){
    this.setState({
        picture:e.target.files[0]
    });
  }

}


export default CreateItem;