import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';

class RegisterPage extends React.Component{
    constructor(props){
        super(props);
        this.state = {
          campUserName: "",
          campPassword:"",
          campEmail:"",
          selectGender: "",
          selectRole: ""
        }
    }

      render(){
        return (
          <div>
            <div className="form-row justify-content-center">
              <div className="form-group col-12">
                <label>username</label>
                <input type="text" className="form-control" value={this.state.campUserName} onChange={(value)=> this.setState({campUserName:value.target.value})}/>
              </div>
              <div className="form-group col-12">
                <label>password</label>
                <input type="password" className="form-control" value={this.state.campPassword} onChange={(value)=> this.setState({campPassword:value.target.value})}/>
              </div>
            </div>
            <div className="form-row">
              <div className="form-group col-12">
                <label>Gender</label>
                <select id="inputGender" className="form-control" onChange={(value)=> this.setState({selectGender:value.target.value})}>
                  <option selected>Choose...</option>
                  <option value="M">Male</option>
                  <option value="F">Female</option>
                </select>
              </div>
              <div className="form-group col-12">
                <label>Role</label>
                <select id="inputRole" className="form-control" onChange={(value)=> this.setState({selectRole:value.target.value})}>
                  <option selected>Choose...</option>
                  <option value="SO">Site Owner</option>
                  <option value="UR">User</option>
                </select>
              </div>
              <div className="form-group col-12">
                <label>Email</label>
                <input type="email" className="form-control" value={this.state.campEmail} onChange={(value)=> this.setState({campEmail:value.target.value})}/>
              </div>
              <div className="form-group col-12">
                <label>Repeat Email</label>
                <input type="email" className="form-control" value={this.state.campEmailAgain} onChange={(value)=> this.setState({campEmailAgain:value.target.value})}/>
              </div>
            </div>

            <button type="submit" className="btn btn-primary" onClick={()=>this.sendSave()}>Submit</button>
            <button type="submit" className="btn btn-primary" style={{float:"right"}} onClick={()=>this.sendReturn()}>Return</button>
          </div>
        );
      }

      sendSave(){
        if (this.state.campUserName==="") {
           alert("Please input user name")
        }
        else if (this.state.campPassword==="") {
           alert("Please input password")
        }
        else if (this.state.selectGender==="") {
           alert("Please select gender")
        }
        else if (this.state.selectRole==="") {
           alert("Please select role")
        }
        else if (this.state.campEmail==="") {
           alert("Please input email")
        }
        else if(!/^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/.test(this.state.campEmail)){
					 alert("Wrong email format");
				}
        else if (this.state.campEmailAgain==="") {
           alert("Please input email again")
        }
        else if(!/^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/.test(this.state.campEmailAgain)){
          alert("Wrong email format again");
        }
        else if (this.state.campEmailAgain!==this.state.campEmail) {
           alert("Please input the same email")
        }
        else {
          const baseUrl = "http://localhost:3001/user/create"
          const datapost = {
            username : this.state.campUserName,
            password : this.state.campPassword,
            email : this.state.campEmail,
            gender : this.state.selectGender,
            role : this.state.selectRole
          }
          axios.post(baseUrl,datapost)
          .then(response=>{
            if (response.data.success===true) {
              alert(response.data.message);
              this.props.history.push("/");
            }
            else {
              alert(response.data.message)
            }
          }).catch(error=>{
            alert("Error 34 "+error)
          })
        }
      }

      sendReturn() {
        window.location.href = "/";
      }

}


export default RegisterPage;