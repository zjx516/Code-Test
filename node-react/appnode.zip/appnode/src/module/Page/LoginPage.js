import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';

class Login extends React.Component{
    constructor(props){
        super(props);
        this.state = {
          campUserName: "",
          campPassword:"",
          selectRole:""
        }
    }

    onEnter() {
      if (window.sessionStorage.getItem("username") === null) {
          window.location.href="/";
      }
    }

      render(){
        return (
          <div>
            <div className="form-row justify-content-center">
              <div className="form-group col-12">
                <label>username</label>
                <input type="text" className="form-control" onChange={(value)=> this.setState({campUserName:value.target.value})}/>
              </div>
              <div className="form-group col-12">
                <label>password</label>
                <input type="password" className="form-control" onChange={(value)=> this.setState({campPassword:value.target.value})}/>
              </div>
              <div className="form-group col-12">
                <label>Role</label>
                <select className="form-control" onChange={(value)=> this.setState({selectRole:value.target.value})}>
                  <option selected>Choose...</option>
                  <option value="SO">Site Owner</option>
                  <option value="UR">User</option>
                </select>
              </div>
            </div>
            <button type="submit" className="btn btn-primary" onClick={()=>this.sendCheck()}>Login</button>
            <button type="submit" className="btn btn-primary float-right" onClick={()=>this.sendSignUp()}>Sign up</button>
          </div>
        );
      }

      sendCheck(){
        if (this.state.campUserName==="") {
           alert("Please input user name")
        }
        else if (this.state.campPassword==="") {
           alert("Please input password")
        }
        else if (this.state.selectRole==="") {
          alert("Please select role")
        }
        else {
          const baseUrl = "http://localhost:3001/user/check"
          const datapost = {
            username : this.state.campUserName,
            password : this.state.campPassword,
            role : this.state.selectRole
          }
          axios.post(baseUrl,datapost)
          .then(response=>{
            if (response.data.success===true) {
              alert(response.data.message);
              window.sessionStorage.setItem("username", response.data.data.username);
              window.sessionStorage.setItem("role", response.data.data.role);
              this.props.history.push("/");
              window.location.reload();
            }
            else {
              alert(response.data.message)
            }
          }).catch(error=>{
            alert("Error 34 "+error)
          })
        }
      }

      sendSignUp(){
        this.props.history.push("/register");
      }

}


export default Login;