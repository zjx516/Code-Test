import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
import PicForm from './PicForm';

class ListItem extends React.Component  {
    constructor(props){
        super(props);
        this.state = {
          listItem:[]
        }
    }

    componentDidMount(){
        axios.get("http://localhost:3001/item/list")
        .then(res => {
          const data = res.data;
          this.setState({ listItem:data });
        })
        .catch(error => {
          alert(error)
        });
  
      }
  
    render(){
        return (
          <div>
              <button id="fat-btn" className="btn btn-warning float-right" onClick={()=>this.redirectToItemForm()}>Add Items</button>
              <br/>
              <table className="table table-hover table-striped">
                <thead className="thead-dark">
                  <tr>
                    <th scope="col">id</th>
                    <th scope="col">name</th>
                    <th scope="col">price</th>
                    <th scope="col">photo</th>
                    <th scope="col">description</th>
                    <th scope="col">expiryDate</th>
                    <th scope="col">status</th>
                    <th colSpan="3" style={{textAlign: "center"}}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {this.loadFillData()}
                </tbody>
                </table>
            </div>
        );
    }
    
    loadFillData(){
        return this.state.listItem.map((data)=>{
          return(
            <tr key={data.id}>
              <th>{data.id}</th>
              <td>{data.name}</td>
              <td>{data.price}</td>
              <td>
                 <PicForm data={data}/>
              </td>
              <td>{data.description}</td>
              <td>{data.expiryDate}</td>
              <td>{data.status}</td>
              <td>
                {window.sessionStorage.getItem("username") !== null && window.sessionStorage.getItem("role") === 'SO' ?
                  <button className="btn btn-outline-info" onClick={()=>this.sendEdit(data)}> Edit </button> :
                  null
                }  
              </td>
              <td>
                {window.sessionStorage.getItem("username") !== null && window.sessionStorage.getItem("role") === 'SO' ?
                  <button className="btn btn-outline-danger" onClick={()=>this.sendDelete(data)}> Delete </button> :
                  null
                }  
              </td>
              <td>
                <button className="btn btn-outline-primary" onClick={()=>this.sendMessage(data.id)}>Message</button>
              </td>
            </tr>
          )
        });
    }

    redirectToItemForm() {
      if(window.sessionStorage.getItem("username")!==null) {
        this.props.history.push("/create");
      }else {
        alert("Login first");
        window.location.href = "/login";
      }
      
    }

    sendEdit(data) {
      this.props.history.push("/edit", {
        data: data,
      });
    }

    sendDelete(data) {
      const baseUrl = "http://localhost:3001/item/delete"
      const datapost = {
        itemId : data.id
      }
      axios.post(baseUrl,datapost)
      .then(response=>{
        if (response.data.success===true) {
          alert(response.data.message);
          window.location.reload();
        }
        else {
          alert(response.data.message)
        }
      }).catch(error=>{
        alert("Error 34 "+error)
      })
    }

    sendMessage(id) {
      if(window.sessionStorage.getItem("username") === null) {
        alert("Please login first");
        window.location.href = "/login";
      }else {
        this.props.history.push("/message", {
          data: id,
        });
      }  
    }

}

export default ListItem;