import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';


class Logout extends React.Component{

      render(){
        return (
            <button className="btn btn-primary" onClick={()=>this.logout()}>Logout</button>
        )
      }

     logout() {
        window.sessionStorage.removeItem("username");
        window.sessionStorage.removeItem("role");
        alert("Logout Successfully");
        setTimeout(function(){
            window.location.href="/";
        },1000);
     }

}


export default Logout;