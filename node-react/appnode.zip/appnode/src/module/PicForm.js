import React from 'react';
import axios from 'axios';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

class PicForm extends React.Component{

  render(){
    return (
      <div>
        {this.props.data.photo === "" ?
          <div>
            <div>
              {/* <input name="image" type="file" style={{backgroundImage: "url("+process.env.PUBLIC_URL+ "/images/plus.jpg)"}}/> */}
              <input name="image" type="file"/>
              <img src={process.env.PUBLIC_URL + '/images/plus.jpg'} alt="upload"/>
            </div>
            <div>
              <button name="upload" onClick={()=>this.uploadPhoto()}>Upload</button>
            </div>
          </div>  :
          <div>
            <div>
              <img src={process.env.PUBLIC_URL + '/images/' + this.props.data.photo} alt="upload"/>
            </div>
            <div>
              <button onClick={()=>this.uploadPhoto()}>Change</button>
            </div>
          </div>
        }
      </div>
    )
  }

  uploadPhoto() {
    const baseUrl = "http://localhost:3001/pic/upload"
    const datapost = {
      id : this.props.data.id
    }
    axios.post(baseUrl,datapost)
    .then(response=>{
      if (response.data.success===true) {
        alert(response.data.message);
        window.location.reload();
      }
      else {
        alert(response.data.message)
      }
    }).catch(error=>{
      alert("Error 34 "+error)
    }) 
  }

}

export default PicForm;