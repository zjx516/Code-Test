import React from 'react';
import axios from 'axios';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

class PicForm extends React.Component{
  state = {
    selectedFile: null

  }
  
  render(){
    return (
      <div>
        {this.props.data.photo === "" ? null:
          <div>
            <img src={process.env.PUBLIC_URL + '/images/' + this.props.data.photo} alt="upload"/>
          </div>
        }
        <input name="image" type="file" onChange={(e) => this.inputPhoto(e)} style={{color:"transparent", width:"100px", margin:"0 auto", display:"block"}}/>
        <button name="upload" onClick={()=>this.uploadPhoto()} style={{margin:"2px auto", display:"block"}}>Upload</button>
      </div>
    )
  }

  inputPhoto(e) {
    this.setState({selectedFile: e.target.files[0]})
  }

  uploadPhoto() {
    const fd = new FormData();
    fd.append('image', this.state.selectedFile, this.state.selectedFile.name);
    fd.append('id', this.props.data.id);
    const baseUrl = "http://localhost:3001/pic/upload"
    axios.post(baseUrl, fd)
    .then(response=>{
      console.log('898989', response);
      if (response.data.success===true) {
        alert(response.data.message);
        window.location.reload();
      }
      else {
        alert(response.data.message)
      }
    }).catch(error=>{
      alert("Error 34 "+error)
    }) 
  }

}

export default PicForm;