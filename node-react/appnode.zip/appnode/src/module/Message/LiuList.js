import React from 'react';

import LiuItem from './LiuItem';
class LiuList extends React.Component{
    render(){
        let todos=this.props.data;
       
        let todoItems=todos.map(item=>{
            return <LiuItem deleteItem={this.props.deleteItem} key={item.id} data={item} symbol="2"/>
        });
        


        return (
            <table className="table table-striped">
                <tbody>
                    {todoItems}
                </tbody>
                
            </table>
          


        );
    }
}

export default LiuList;