import React from 'react';

import LiuList from './LiuList';
import LiuExistedList from './LiuExistedList';
import LiuForm from './LiuForm';

class LiuApp extends React.Component{

    constructor(props){
    
        super(props);
        this.ids=1;
        this.state={
                todos:[]
        };
        this.addItem=this.addItem.bind(this);
        this.deleteItem=this.deleteItem.bind(this);
    }
    deleteItem(id){
        let newtodos=this.state.todos.filter((item)=>{
            return !(item.id===id)
        });
          this.setState({
            todos:newtodos
        });

    }

    addItem(value){
       this.state.todos.unshift(
            {
                id:this.ids++,
                content:value,
                createDate:(new Date()).toLocaleString(),
                done:0
            }
        )

        this.setState({
            todos:this.state.todos
        });
    }

    render(){
        const itemId = this.props.location.state.data;
        return (
            <div className="container">
                <br/>
                <br/>
                <br/>
                <br/>
                <div className="panel panel-default">
                    <div className="panel-headingbg-danger">
                            <h1 className="text-center">Message Board</h1>
                            <hr/>
                    </div>
                    <div className="panel-body">
                             <LiuExistedList/>
                             <LiuList deleteItem={this.deleteItem} data={this.state.todos}/>
                             <LiuForm addItem={this.addItem} data={itemId}/>
                    </div>
                </div> 
            </div>
          
        );
    }
}

export default LiuApp;