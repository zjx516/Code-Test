import React from 'react';
import MessageItem from './MessageItem';

class MessageList extends React.Component{
    render(){
        let todos=this.props.data;
       
        let todoItems=todos.map(item=>{
            return <MessageItem deleteItem={this.props.deleteItem} key={item.id} data={item} itemId={this.props.itemId} symbol="2"/>
        });
        
        return (
            <table className="table table-striped">
                <tbody>
                    {todoItems}
                </tbody>
            </table>
        );
    }
}

export default MessageList;