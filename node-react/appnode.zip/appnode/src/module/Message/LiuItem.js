import React from 'react';


class LiuItem extends React.Component{

    delete(){
        if(this.props.symbol === "2") {
            this.props.deleteItem(this.props.data.id);
        }else if(this.props.symbol === "1") {
            alert("can't delete existed message");
        }
    }

    render(){
        let {content,createDate}=this.props.data;

        return (
           <tr>
               <td>{createDate}<br/><br/>{content}</td>

                <td>
                    <br/>
                    <br/>
                   <button className="btn btn-primary" onClick={this.delete.bind(this)}>Delete Message</button>
                </td>
           </tr>


        );
    }
}

export default LiuItem;