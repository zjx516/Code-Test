import React from 'react';
import axios from 'axios';

class MessageForm extends React.Component{
    tijiao(event){
        event.preventDefault();
    }

    add(event){
        if(event.type==="keyup"&&event.keyCode!==13){
            return false;
        }
        let txt=this.refs.txt.value;
        if(txt==="") return false;
        this.props.addItem(txt);
        this.refs.txt.value="";
        this.sendMessageToDB(txt);
    }

    back(){
      window.location.href = "/";
    }

    render(){
        return(
             <form className="form-horizontal" onSubmit={this.tijiao.bind(this)}>
                <div className="form-group">
                    <div className="col-sm-10">
                        <input ref="txt"  type="text" className="form-control" onKeyUp={this.add.bind(this)} id="exampleInputName2" placeholder="Write new message"/>
                    </div>
                    <div className="col-sm-10">
                      <button type="button" className="btn btn-primary" onClick={this.add.bind(this)}>Send</button>
                      <button type="button" className="btn btn-primary" style={{float: "right"}} onClick={this.back.bind(this)}>Return</button>
                    </div>
                </div>
            </form>
        );
    }

    sendMessageToDB(word){
        const baseUrl = "http://localhost:3001/message/create"
        const datapost = {
          itemId : this.props.data,
          username : window.localStorage.username,
          content : word
        }
        let storage = window.localStorage;
        axios.post(baseUrl,datapost)
        .then(response=>{
          if (response.data.success===true) {
            alert(response.data.message);
            storage.username = response.data.data.username;
          }
          else {
            alert(response.data.message)
          }
        }).catch(error=>{
          alert("Error 34 "+error)
        })
    }

}
export default MessageForm;