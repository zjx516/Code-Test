import React from 'react';
import axios from 'axios';
import MessageItem from './MessageItem';


class MessageList extends React.Component{
    constructor(props){
        super(props);
        this.state = {
          listMessage:[]
        }
    }

    componentDidMount(){
        axios.get("http://localhost:3001/message/get")
        .then(res => {
          const data = res.data;
          this.setState({ listMessage:data });
        })
        .catch(error => {
          alert(error)
        });
    }

    
    render(){
        const listMessages = this.state.listMessage;
        let existedMessages=listMessages.map(item=>{
            return <MessageItem key={item.id} data={item} symbol="1"/>
        });

        return (
            <table className="table table-striped">
                <tbody>
                    {existedMessages}
                </tbody>
            </table>
        );
    }
}

export default MessageList;