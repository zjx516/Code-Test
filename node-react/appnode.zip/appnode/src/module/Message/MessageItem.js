import React from 'react';
import axios from 'axios';

class MessageItem extends React.Component{

    delete(){
        this.props.deleteItem(this.props.data.id);
        this.deleteMessageFromDB();
    }

    render(){
        let {content,createDate}=this.props.data;

        return (
           <tr>
               {this.props.symbol === "2" ?
                <td style={{float:"right"}}>{createDate}<br/><br/>{content}</td>:
                <td>{createDate}<br/><br/>{content}</td>
               }
                <td style={{float:"left"}}>
                    <br/>
                    <br/>
                    {this.props.symbol === "2" ?
                        <button className="btn btn-primary" onClick={this.delete.bind(this)}>Delete Message</button>:
                        null
                    }
                </td>
           </tr>
        );
    }

    deleteMessageFromDB() {
        const baseUrl = "http://localhost:3001/message/delete"
        const datapost = {
          itemId : this.props.itemId,
          username : window.localStorage.username,
          content : this.props.data.content
        }
        axios.post(baseUrl,datapost)
        .then(response=>{
          if (response.data.success===true) {
            alert(response.data.message);
          }
          else {
            alert(response.data.message)
          }
        }).catch(error=>{
          alert("Error 34 "+error)
        })
    }

}

export default MessageItem;